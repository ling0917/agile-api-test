"""
自动加密/解密YAML文件中的密码
运行: 
  加密: python tools/auto_encrypt_yaml.py
  解密: python tools/auto_encrypt_yaml.py --decrypt
"""
import sys
import os
import re
import shutil
from datetime import datetime

# 加到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from utils.crypto_util import encrypt, decrypt


def process_yaml_file(filename, mode='encrypt'):
    """处理YAML文件"""
    
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    file_path = os.path.join(base_dir, "data", filename)
    
    # 检查文件是否存在
    if not os.path.exists(file_path):
        print(f"❌ 文件不存在: {file_path}")
        return
    
    # 备份原文件
    backup_path = file_path + f".backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(file_path, backup_path)
    print(f"📋 已备份: {backup_path}")
    
    # 读取原文件
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # 匹配 password: "xxx" 或 password: 'xxx'，可能已有 # plain: 注释
    pattern = r'(password:\s*["\'])([^"\']+)(["\'])(\s*# plain: [^"\']+)?'
    
    def replace_password(match):
        prefix = match.group(1)      # password: "
        value = match.group(2)       # 当前值
        suffix = match.group(3)      # "
        old_comment = match.group(4) or ""  # 已有注释
        
        if mode == 'encrypt':
            # 跳过已是密文的
            if value.startswith('gAAAA'):
                return match.group(0)
            
            encrypted = encrypt(value)
            print(f"🔒 加密: {value} -> {encrypted[:20]}...")
            # 保留明文注释
            return f'{prefix}{encrypted}{suffix}  # plain: {value}'
        
        else:  # decrypt
            # 跳过已是明文的
            if not value.startswith('gAAAA'):
                return match.group(0)
            
            plain = decrypt(value)
            print(f"🔓 解密: {value[:20]}... -> {plain}")
            # 去掉注释
            return f'{prefix}{plain}{suffix}'
    
    # 替换所有密码
    new_content = re.sub(pattern, replace_password, content)
    
    # 写回文件
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(new_content)
    
    print(f"✅ 已更新: {file_path}")


def main():
    # 解析参数
    mode = 'decrypt' if '--decrypt' in sys.argv else 'encrypt'
    files = [f for f in sys.argv[1:] if not f.startswith('--')]
    
    # 确认密钥
    key = os.getenv("AES_KEY", "")
    if not key:
        action = '解密' if mode == 'decrypt' else '加密'
        key = input(f"⚠️ 未设置AES_KEY环境变量，请输入{action}密钥: ").strip()
        os.environ["AES_KEY"] = key
    
    print(f"🔑 使用密钥: {key[:3]}***，模式: {mode}\n")
    
    # 处理文件
    if not files:
        files = ["test_data.yaml"]
    
    for filename in files:
        print(f"\n📄 处理: {filename}")
        process_yaml_file(filename, mode)


if __name__ == "__main__":
    main()