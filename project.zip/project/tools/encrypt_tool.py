"""
密码加密工具
运行: python tools/encrypt_tool.py
"""
import sys
import os

# 加到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from utils.crypto_util import encrypt


def main():
    # 强制从环境变量读取，不交互
    key = os.getenv("AES_KEY", "")
    if not key:
        key = input("输入加密密钥: ").strip()
        os.environ["AES_KEY"] = key
    
    print(f"使用密钥: {key[:3]}***")
    
    passwords = {
        "demo_po": "password",
        "demo_sm": "password",
        "demo_dev": "password",
        "admin": "123456",
        "wrong": "wrong",
    }
    
    print("\n=== 加密结果 ===\n")
    for name, pwd in passwords.items():
        encrypted = encrypt(pwd)
        print(f"# {name} ({pwd})")
        print(f"password: \"{encrypted}\"")
        print()


if __name__ == "__main__":
    main()