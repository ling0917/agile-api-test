# conftest.py（项目根目录）

import pytest
import os
import allure
from api.user_api import UserApi
from utils.response_util import ResponseUtil
from utils.db_util import DBUtil


def pytest_sessionstart(session):
    """测试会话开始时生成Allure环境文件"""
    allure_dir = session.config.getoption("--alluredir", default="reports/allure-results")
    if allure_dir:
        os.makedirs(allure_dir, exist_ok=True)
        env_file = os.path.join(allure_dir, "environment.properties")
        with open(env_file, "w", encoding="utf-8") as f:
            f.write("Project=Agile API Test\n")
            f.write(f"Environment={os.getenv('ENV', 'local')}\n")
            f.write("Base URL=http://localhost:8084\n")
            f.write("Database=localhost:3307/agile\n")
            f.write("Python=3.14.8\n")
            f.write("pytest=9.1.1\n")


def login_user(username, password):
    """通用登录"""
    with allure.step(f"login: {username}"):
        resp = UserApi.login(username, password)
        assert resp.status_code == 200, f"登录HTTP失败: {resp.status_code}, {resp.text}"
        json_data = resp.json()
        assert json_data and json_data.get("code") == 200, f"登录业务失败: {json_data}"
        token = json_data.get("data", {}).get("token")
        assert token, f"Token为空: {json_data}"
        allure.attach(resp.text, name="login response", attachment_type=allure.attachment_type.JSON)
        return token


@pytest.fixture(scope="session")
def token_po():
    """PRODUCT_OWNER token"""
    return login_user("demo_po", "password")


@pytest.fixture(scope="session")
def token_sm():
    """SCRUM_MASTER token"""
    return login_user("demo_sm", "password")


@pytest.fixture(scope="session")
def token_dev():
    """DEVELOPER token"""
    return login_user("demo_dev", "password")


# ==================== 数据清理 ====================

@pytest.fixture(scope="function", autouse=True)
def cleanup_test_data():
    """
    每个测试方法执行后清理测试数据
    """
    yield  # 测试执行
    
    # 测试结束后清理
    with allure.step("Cleanup: 清理测试数据"):
        try:
            # 清理项目（参数化，避免%格式化问题）
            deleted_projects = DBUtil.execute_update(
                "DELETE FROM project WHERE name LIKE %s OR name LIKE %s OR name = %s",
                ("PO_Test_%", "SM_Test_%", "DuplicateTest")
            )
            if deleted_projects > 0:
                allure.attach(f"删除 {deleted_projects} 个测试项目", "清理项目")
            
            # 清理Story
            deleted_stories = DBUtil.execute_update(
                "DELETE FROM story WHERE title LIKE %s OR title LIKE %s",
                ("PO_Test_%", "SM_Test_%")
            )
            if deleted_stories > 0:
                allure.attach(f"删除 {deleted_stories} 个测试Story", "清理Story")
            
            # 清理Sprint
            deleted_sprints = DBUtil.execute_update(
                "DELETE FROM sprint WHERE name LIKE %s",
                ("SM_Test_%",)
            )
            if deleted_sprints > 0:
                allure.attach(f"删除 {deleted_sprints} 个测试Sprint", "清理Sprint")
                
        except Exception as e:
            allure.attach(f"清理失败: {str(e)}", "清理异常")