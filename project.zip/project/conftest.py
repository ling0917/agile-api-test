# conftest.py
import pytest
import allure
from api.user_api import UserApi
from utils.response_util import ResponseUtil


def login_user(username, password):
    """通用登录"""
    with allure.step(f"login: {username}"):
        resp = UserApi.login(username, password)
        assert resp.status_code == 200
        
        json_data = ResponseUtil.get_json(resp)
        assert json_data and json_data.get("code") == 200
        
        token = ResponseUtil.extract_value(resp, "data", "token")
        assert token is not None
        
        allure.attach(resp.text, name="login response", attachment_type=allure.attachment_type.JSON)
        
        return token


@pytest.fixture(scope="session")
def token_po():
    """PRODUCT_OWNER token"""
    return login_user("demo_po", "password")


@pytest.fixture(scope="session")
def token_sm():
    """SCRUM_MASTER token"""
    return login_user("demo_sm", "password")


@pytest.fixture(scope="session")
def token_dev():
    """DEVELOPER token"""
    return login_user("demo_dev", "password")  # 如果有这个用户