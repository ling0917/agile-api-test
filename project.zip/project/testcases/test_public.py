# testcases/test_public.py
import allure
import pytest
from testcases.base.test_base import TestBase
from api.project_api import ProjectApi
from api.sprint_api import SprintApi
from api.story_api import StoryApi
from api.task_api import TaskApi
from api.kanban_api import KanbanApi


@allure.feature("Public APIs")
@allure.story("Read-only queries")
class TestPublic(TestBase):
    """公共查询接口，任何角色都能访问"""
    
    @allure.title("Get Projects")
    @pytest.mark.smoke
    def test_get_projects(self, token_sm):  # 用哪个角色都行
        resp = ProjectApi.get_projects(token_sm)
        data = self.assert_success(resp)
        projects = data.get("data", [])
        if projects:
            self.assert_field_exists(projects[0], "id", "name", "ownerId", "createdAt")
    
    @allure.title("Get Sprints")
    @pytest.mark.smoke
    def test_get_sprints(self, token_sm):
        resp = SprintApi.get_sprints(token_sm)
        data = self.assert_success(resp)
        sprints = data.get("data", [])
        if sprints:
            self.assert_field_exists(sprints[0], "id", "name", "status", "projectId")
    
    @allure.title("Get Stories")
    @pytest.mark.smoke
    def test_get_stories(self, token_sm):
        resp = StoryApi.get_stories(token_sm)
        data = self.assert_success(resp)
        stories = data.get("data", [])
        if stories:
            self.assert_field_exists(stories[0], "id", "title", "status")
    
    @allure.title("Get Tasks")
    @pytest.mark.smoke
    def test_get_tasks(self, token_sm):
        resp = TaskApi.get_tasks(token_sm)
        data = self.assert_success(resp)
        tasks = data.get("data", [])
        if tasks:
            self.assert_field_exists(tasks[0], "id", "title", "status")
    
    @allure.title("Get Kanban Board")
    @pytest.mark.smoke
    def test_get_kanban_board(self, token_sm):
        # 先获取sprint
        resp = SprintApi.get_sprints(token_sm)
        sprints = self.assert_success(resp).get("data", [])
        if not sprints:
            pytest.skip("No sprint")
        
        sprint_id = sprints[0]["id"]
        resp = KanbanApi.get_board(token_sm, sprint_id)
        data = self.assert_success(resp)
        board = data.get("data", {})
        self.assert_field_exists(board, "todo", "doing", "done")