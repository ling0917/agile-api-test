# testcases/base/test_base.py

import allure
import json
from typing import Any, Dict, List, Optional, Union
from utils.response_util import ResponseUtil


class TestBase:
    """通用断言方法，所有测试类继承"""
    
    # ==================== Level 1: HTTP层 ====================
    
    @staticmethod
    def assert_status_code(resp, expected: Union[int, List[int]]):
        """断言HTTP状态码"""
        actual = resp.status_code
        if isinstance(expected, list):
            assert actual in expected, f"HTTP状态码错误: 预期{expected}, 实际{actual}"
        else:
            assert actual == expected, f"HTTP状态码错误: 预期{expected}, 实际{actual}"
        return True
    
    # ==================== Level 2: 业务层 ====================
    
    @staticmethod
    def assert_success(resp):
        """断言请求成功（你的项目约定：HTTP200 + code200）"""
        # 先用response_util
        assert ResponseUtil.is_success(resp), f"HTTP失败: {resp.status_code}"
        
        json_data = ResponseUtil.get_json(resp)
        assert json_data is not None, "响应不是JSON"
        assert json_data.get("code") == 200, f"业务失败: {json_data}"
        
        return json_data
    
    @staticmethod
    def assert_error(resp, expected_http: int, expected_code: Optional[int] = None):
        """断言业务错误 - 适配 HTTP 200 + code 错误码的设计"""
    
        # 验 HTTP 状态码（你的后端都是 200）
        actual_http = resp.status_code
        assert actual_http == expected_http, f"HTTP状态码错误: 预期{expected_http}, 实际{actual_http}"
        
        # 验业务码
        json_data = ResponseUtil.get_json(resp)
        assert json_data is not None, "响应不是JSON"
        
        if expected_code is not None:
            actual_code = json_data.get("code")
            assert actual_code == expected_code, f"业务码错误: 预期{expected_code}, 实际{actual_code}"
        
        return json_data
    
    # ==================== Level 3: 数据层 ====================
    
    @staticmethod
    def assert_field_exists(data, *fields):
        """断言字段存在"""
        for field in fields:
            assert field in data, f"缺少字段: {field}"
    
    @staticmethod
    def assert_field_value(data, field, expected):
        """断言字段值"""
        actual = data.get(field) if isinstance(data, dict) else getattr(data, field, None)
        assert actual == expected, f"字段{field}: 预期{expected}, 实际{actual}"
    
    @staticmethod
    def assert_list_not_empty(data_list):
        """断言列表非空"""
        assert isinstance(data_list, list), "数据不是列表"
        assert len(data_list) > 0, "列表为空"
    
    @staticmethod
    def assert_token_valid(data):
        """断言token有效"""
        import re
        token = data.get("token")
        assert token is not None, "Token为空"
        assert len(token) > 10, "Token太短"
        # JWT格式验证
        assert re.match(r'^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$', token), \
            "Token格式错误"
        return token
    
    # ==================== Level 4: 数据库层（新增）====================
    
    @staticmethod
    def assert_db_record_exists(table: str, condition: str, params: tuple = ()):
        """断言数据库记录存在"""
        from utils.db_util import DBUtil
        result = DBUtil.execute_query(f"SELECT * FROM {table} WHERE {condition}", params)
        assert len(result) > 0, f"记录不存在: {table} WHERE {condition}"
        return result[0]
    
    @staticmethod
    def assert_db_field_value(table: str, condition: str, field: str, expected, params: tuple = ()):
        """断言数据库字段值"""
        from utils.db_util import DBUtil
        result = DBUtil.execute_query(f"SELECT {field} FROM {table} WHERE {condition}", params)
        assert len(result) > 0, f"记录不存在"
        actual = result[0].get(field)
        assert actual == expected, f"DB字段{field}: 预期{expected}, 实际{actual}"
    
    # ==================== Allure附件 ====================
    
    @staticmethod
    def attach_response(resp, name="API Response"):
        """附加响应到Allure报告"""
        allure.attach(
            resp.text,
            name=name,
            attachment_type=allure.attachment_type.JSON
        )