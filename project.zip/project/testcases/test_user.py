# testcases/test_user.py
import allure
import pytest
from testcases.base.test_base import TestBase
from api.user_api import UserApi
from utils.yaml_util import read_yaml
from utils.db_util import DBUtil
from config.settings import CURRENT

yaml_data = read_yaml("test_data.yaml")
login_cases = yaml_data["login_cases"]


@allure.feature("User Module")
@allure.story("Login")
class TestUser(TestBase):
    
    @allure.title("Login Test - {case[name]}")
    @pytest.mark.parametrize("case", login_cases)
    @pytest.mark.smoke
    def test_login(self, case):
        """login + db verify"""
        
        with allure.step("Step0: verify env"):
            allure.attach(
                f"ENV: {CURRENT.__class__.__name__}\nURL: {CURRENT.BASE_URL}\nDB: {CURRENT.DB_HOST}:{CURRENT.DB_PORT}/{CURRENT.DB_NAME}",
                name="Environment",
                attachment_type=allure.attachment_type.TEXT
            )
        
        with allure.step("Step1: call login api"):
            resp = UserApi.login(case["username"], case["password"])
            data = self.assert_success(resp)
            self.attach_response(resp)
        
        with allure.step("Step2: verify response data"):
            resp_data = data.get("data", {})
            
            if "错误" in case["name"]:
                assert resp_data.get("token") is None or resp_data.get("message") == "密码错误"
                allure.attach("Login failed as expected", "Result")
                return
            
            self.assert_token_valid(resp_data)
            self.assert_field_value(resp_data, "username", case["username"])
            
            expected_role = case.get("expected_role")
            if expected_role:
                self.assert_field_value(resp_data, "role", expected_role)
            else:
                assert resp_data.get("role"), "Role is empty"
        
        with allure.step("Step3: db verify"):
            # 查询用户基础信息（无 last_login_time 字段）
            db_users = DBUtil.execute_query(
                "SELECT id, username, role, email, nickname FROM user WHERE username = %s",
                (case["username"],)
            )
            
            allure.attach(str(db_users), "DB Result", allure.attachment_type.TEXT)
            
            # 基础验证
            self.assert_list_not_empty(db_users)
            self.assert_field_value(db_users[0], "username", case["username"])
            
            # 角色验证
            if expected_role:
                self.assert_field_value(db_users[0], "role", expected_role)
            
            # 邮箱验证（非空即可）
            assert db_users[0].get("email"), "DB邮箱为空"
            
            # 昵称验证（非空即可）
            assert db_users[0].get("nickname"), "DB昵称为空"

    @allure.title("Get User Info")
    @pytest.mark.smoke
    def test_get_user_info(self, token_sm):
        resp = UserApi.get_user_info(token_sm)
        data = self.assert_success(resp)
        self.attach_response(resp)
        
        user = data.get("data", {})
        self.assert_field_exists(user, "id", "username", "role", "email", "nickname")
        assert user.get("username") in ["demo_po", "demo_sm", "demo_dev"]
        
        with allure.step("DB verify - user exists and consistent"):
            db_user = self.assert_db_record_exists(
                "user",
                "username = %s",
                (user.get("username"),)
            )
            # 验证API返回和DB一致
            self.assert_field_value(db_user, "username", user.get("username"))
            self.assert_field_value(db_user, "role", user.get("role"))
            self.assert_field_value(db_user, "email", user.get("email"))
            self.assert_field_value(db_user, "nickname", user.get("nickname"))