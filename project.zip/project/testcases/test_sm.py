# testcases/test_sm.py
import allure
import pytest
from testcases.base.test_base import TestBase
from api.sprint_api import SprintApi
from api.kanban_api import KanbanApi
from api.task_api import TaskApi
from api.project_api import ProjectApi


@allure.feature("SCRUM_MASTER APIs")
@allure.story("SM exclusive operations")
class TestSM(TestBase):
    """SCRUM_MASTER 专属：管理 Sprint、看板、任务状态"""
    
    @allure.title("Create Sprint")
    @pytest.mark.smoke
    def test_create_sprint(self, token_sm):
        with allure.step("Step0: Get project"):
            resp = ProjectApi.get_projects(token_sm)
            projects = self.assert_success(resp).get("data", [])
            if not projects:
                pytest.skip("No project")
            project_id = projects[0]["id"]
        
        sprint_name = "SM_Test_Sprint_DB"
        start_date = "2024-01-01"
        end_date = "2024-01-14"
        
        with allure.step("Step1: Create sprint via API"):
            resp = SprintApi.create_sprint(token_sm, project_id, sprint_name, start_date, end_date)
            data = self.assert_success(resp)
            self.attach_response(resp)
            
            sprint = data.get("data", {})
            self.assert_field_exists(sprint, "id", "name", "status")
            # 数据库默认是 OPEN，但后端可能返回 PLANNING
            # self.assert_field_value(sprint, "status", "PLANNING")
            sprint_id = sprint.get("id")
        
        with allure.step("Step2: DB verify - record exists"):
            db_sprint = self.assert_db_record_exists(
                "sprint",
                "name = %s",
                (sprint_name,)
            )
            allure.attach(str(db_sprint), "DB Sprint", allure.attachment_type.JSON)
        
        with allure.step("Step3: DB verify - field values"):
            self.assert_db_field_value("sprint", "name = %s", "name", sprint_name, (sprint_name,))
            # 根据实际后端返回调整状态验证
            # self.assert_db_field_value("sprint", "name = %s", "status", "PLANNING", (sprint_name,))
    
    @allure.title("Start Sprint")
    @pytest.mark.smoke
    def test_start_sprint(self, token_sm):
        with allure.step("Step0: Get planning sprint"):
            resp = SprintApi.get_sprints(token_sm)
            sprints = self.assert_success(resp).get("data", [])
            planning_sprints = [s for s in sprints if s.get("status") == "PLANNING"]
            if not planning_sprints:
                pytest.skip("No planning sprint")
            sprint_id = planning_sprints[0]["id"]
        
        with allure.step("Step1: Start sprint via API"):
            resp = SprintApi.start_sprint(token_sm, sprint_id)
            data = self.assert_success(resp)
            self.attach_response(resp)
            
            sprint = data.get("data", {})
            self.assert_field_value(sprint, "status", "ACTIVE")
        
        with allure.step("Step2: DB verify - status updated"):
            self.assert_db_field_value(
                "sprint",
                "id = %s",
                "status",
                "ACTIVE",
                (sprint_id,)
            )
    
    @allure.title("Update Task Status")
    @pytest.mark.smoke
    def test_update_task_status(self, token_sm):
        with allure.step("Step0: Get TODO task"):
            resp = TaskApi.get_tasks_by_status(token_sm, "TODO")
            tasks = self.assert_success(resp).get("data", [])
            if not tasks:
                pytest.skip("No TODO task")
            task_id = tasks[0]["id"]
            old_status = tasks[0]["status"]
        
        try:
            with allure.step("Step1: Update task to DOING via API"):
                resp = KanbanApi.update_task_status(token_sm, task_id, "DOING")
                data = self.assert_success(resp)
                self.attach_response(resp)
                
                result = data.get("data", {})
                self.assert_field_value(result, "newStatus", "DOING")
                self.assert_field_value(result, "success", True)
            
            with allure.step("Step2: Verify via API"):
                resp = TaskApi.get_task(token_sm, task_id)
                task = self.assert_success(resp).get("data", {})
                self.assert_field_value(task, "status", "DOING")
            
            with allure.step("Step3: DB verify - status updated"):
                self.assert_db_field_value(
                    "task",
                    "id = %s",
                    "status",
                    "DOING",
                    (task_id,)
                )
        
        finally:
            with allure.step("Cleanup: restore task status"):
                KanbanApi.update_task_status(token_sm, task_id, old_status)
                # DB验证恢复成功
                self.assert_db_field_value(
                    "task",
                    "id = %s",
                    "status",
                    old_status,
                    (task_id,)
                )