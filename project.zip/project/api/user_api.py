from utils.request_util import RequestUtil


class UserApi:
    
    @staticmethod
    def login(username, password):
        """real login api"""
        return RequestUtil.post("/auth/login", json={
            "username": username,
            "password": password
        })
    
    @staticmethod
    def get_user_info(token):
        """real get user info"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get("/auth/me", headers=headers)