from utils.request_util import RequestUtil


class TaskApi:
    
    @staticmethod
    def get_tasks(token):
        """GET /tasks - 获取所有任务"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get("/tasks", headers=headers)
    
    @staticmethod
    def get_task(token, task_id):
        """GET /tasks/{id} - 获取任务详情"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/tasks/{task_id}", headers=headers)
    
    @staticmethod
    def create_task(token, title, description="", status="TODO", priority="MEDIUM", story_points=1):
        """POST /tasks - 创建任务"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.post("/tasks", json={
            "title": title,
            "description": description,
            "status": status,
            "priority": priority,
            "storyPoints": story_points
        }, headers=headers)
    
    @staticmethod
    def update_task(token, task_id, title=None, description=None, status=None, priority=None):
        """PUT /tasks/{id} - 更新任务"""
        headers = {"Authorization": f"Bearer {token}"}
        data = {}
        if title:
            data["title"] = title
        if description:
            data["description"] = description
        if status:
            data["status"] = status
        if priority:
            data["priority"] = priority
        return RequestUtil.put(f"/tasks/{task_id}", json=data, headers=headers)
    
    @staticmethod
    def delete_task(token, task_id):
        """DELETE /tasks/{id} - 删除任务"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.delete(f"/tasks/{task_id}", headers=headers)
    
    @staticmethod
    def get_tasks_by_status(token, status):
        """GET /tasks/status/{status} - 按状态查询"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/tasks/status/{status}", headers=headers)
    
    @staticmethod
    def get_tasks_by_sprint(token, sprint_id):
        """GET /tasks/sprint/{sprintId} - 按迭代查询"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/tasks/sprint/{sprint_id}", headers=headers)