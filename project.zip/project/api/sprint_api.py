from utils.request_util import RequestUtil


class SprintApi:
    
    @staticmethod
    def get_sprints(token, project_id=None):
        """GET /sprints - 获取迭代列表"""
        headers = {"Authorization": f"Bearer {token}"}
        params = {}
        if project_id:
            params["projectId"] = project_id
        return RequestUtil.get("/sprints", headers=headers, params=params)  # ← /sprint → /sprints
    
    @staticmethod
    def create_sprint(token, project_id, name, start_date, end_date, goal=""):
        """POST /sprints - 创建迭代"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.post("/sprints", json={  # ← 复数
            "projectId": project_id,
            "name": name,
            "startDate": start_date,
            "endDate": end_date,
            "goal": goal
        }, headers=headers)
    
    @staticmethod
    def get_sprint(token, sprint_id):
        """GET /sprints/{id} - 获取迭代详情"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/sprints/{sprint_id}", headers=headers)  # ← 复数
    @staticmethod
    def start_sprint(token, sprint_id):
     """PUT /sprints/{id}/start - 启动迭代"""
     headers = {"Authorization": f"Bearer {token}"}
     return RequestUtil.put(f"/sprints/{sprint_id}/start", headers=headers)