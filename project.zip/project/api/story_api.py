from utils.request_util import RequestUtil


class StoryApi:
    
    @staticmethod
    def get_stories(token, sprint_id=None, status=None):
        """GET /stories - 获取故事列表"""
        headers = {"Authorization": f"Bearer {token}"}
        params = {}
        if sprint_id:
            params["sprintId"] = sprint_id
        if status:
            params["status"] = status
        return RequestUtil.get("/stories", headers=headers, params=params)  # ← /story → /stories
    
    @staticmethod
    def create_story(token, sprint_id, title, description="", story_points=0, priority="MEDIUM"):
        """POST /stories - 创建故事"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.post("/stories", json={  # ← 复数
            "sprintId": sprint_id,
            "title": title,
            "description": description,
            "storyPoint": story_points,
            "priority": priority
        }, headers=headers)
    
    @staticmethod
    def get_story(token, story_id):
        """GET /stories/{id} - 获取故事详情"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/stories/{story_id}", headers=headers)  # ← 复数
    @staticmethod
    def get_backlog(token, project_id):
        """GET /stories/backlog?projectId=... - 获取未规划的Backlog"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/stories/backlog?projectId={project_id}", headers=headers)

    @staticmethod
    def plan_to_sprint(token, story_id, sprint_id):
        """POST /stories/{id}/plan?sprintId=... - 规划Story到Sprint"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.post(f"/stories/{story_id}/plan?sprintId={sprint_id}", headers=headers)