# api/kanban_api.py（替换原来的order_api.py）
from utils.request_util import RequestUtil


class KanbanApi:
    
    @staticmethod
    def get_tasks(token, status="ALL"):
        """GET /kanban?status=... - 获取任务列表"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/kanban?status={status}", headers=headers)
    
    @staticmethod
    def get_board(token, sprint_id):
        """GET /kanban/board?sprintId=... - 获取看板"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/kanban/board?sprintId={sprint_id}", headers=headers)
    
    @staticmethod
    def update_task_status(token, task_id, status):
        """POST /kanban/{id}/status?status=... - 更新任务状态"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.post(
            f"/kanban/{task_id}/status?status={status}",
            headers=headers
        )