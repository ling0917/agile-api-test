# api/project_api.py
from utils.request_util import RequestUtil


class ProjectApi:
    
    @staticmethod
    def get_projects(token):
        """GET /projects - 获取项目列表"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get("/projects", headers=headers)
    
    @staticmethod
    def get_project(token, project_id):
        """GET /projects/{id} - 获取项目详情"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.get(f"/projects/{project_id}", headers=headers)
    
    @staticmethod
    def create_project(token, name, description=""):
        """POST /projects - 创建项目（PO专属）"""
        headers = {"Authorization": f"Bearer {token}"}
        return RequestUtil.post("/projects", json={
            "name": name,
            "description": description
        }, headers=headers)