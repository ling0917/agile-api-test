import os


class Config:
    """base config"""
    BASE_URL = "http://localhost:8084"   # ← 你的后端地址
    TIMEOUT = 10
    
    # MySQL配置（Docker映射端口3307）
    DB_HOST = "localhost"
    DB_PORT = 3307                       # ← 关键！不是3306
    DB_USER = "root"
    DB_PASSWORD = "123456"               # ← 你的密码，看.env确认
    DB_NAME = "agile"                    # ← 你的数据库名


class TestConfig(Config):
    """test env"""
    BASE_URL = "http://localhost:8084"
    DB_NAME = "agile_test"


class ProdConfig(Config):
    """prod env"""
    BASE_URL = "http://你的服务器IP:8084"
    DB_NAME = "agile_prod"


env = os.getenv("ENV", "dev").lower()

if env == "test":
    CURRENT = TestConfig
elif env == "prod":
    CURRENT = ProdConfig
else:
    CURRENT = Config

print(f"[ENV] current: {env}, url: {CURRENT.BASE_URL}, db: {CURRENT.DB_NAME}:{CURRENT.DB_PORT}")