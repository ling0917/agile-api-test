# API Automation Test Project

## Project Structure
## Project Structure
api_auto_test/
├── api/              # API layer
├── testcases/        # Test cases
├── data/             # YAML test data
├── config/           # Configuration
├── utils/            # Utilities
├── logs/             # Log files
├── reports/          # Allure reports
├── conftest.py       # Pytest fixtures
└── pytest.ini        # Pytest config
plain

## Setup
```bash
pip install -r requirements.txt
Run Tests
bash
# Run all tests
python -m pytest testcases/ -v

# Generate Allure report
allure serve reports/allure-results
Tech Stack
pytest
requests
PyYAML
PyMySQL
Allure