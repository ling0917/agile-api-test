# check_db.py（临时脚本，放项目根目录）
from utils.db_util import DBUtil

tables = ['project', 'story', 'task']

for table in tables:
    print(f"\n{'='*50}")
    print(f"Table: {table}")
    print('='*50)
    try:
        columns = DBUtil.execute_query(f"DESCRIBE {table}")
        for col in columns:
            print(f"  {col['Field']:20s} | {col['Type']:20s} | {col['Null']:3s} | {str(col.get('Default', '')):10s}")
    except Exception as e:
        print(f"  Error: {e}")