"""
YAML工具
"""
import yaml
import os

# 加密功能已注释，实际工作可用AES加密 + 环境变量注入密钥
# from utils.crypto_util import is_encrypted, decrypt


def read_yaml(filename):
    """读取YAML文件"""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    paths = [
        os.path.join(base_dir, "data", filename),
        os.path.join(base_dir, filename),
    ]
    
    file_path = None
    for p in paths:
        if os.path.exists(p):
            file_path = p
            break
    
    if not file_path:
        raise FileNotFoundError(f"找不到文件: {filename}")
    
    with open(file_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    
    # 加密功能已注释，如需启用，取消下面注释
    # if data and "login_cases" in data:
    #     for case in data["login_cases"]:
    #         if "password" in case and case["password"]:
    #             case["password"] = decrypt(case["password"])
    
    return data


# 解密单个用例密码（已注释）
# def decrypt_case_password(case: dict) -> dict:
#     """解密单个用例的密码"""
#     if "password" in case and case["password"] and is_encrypted(case["password"]):
#         case["password"] = decrypt(case["password"])
#     return case