"""重试装饰器"""

import time
import logging
from functools import wraps

logger = logging.getLogger("retry")


def retry(times=3, delay=1, exceptions=(Exception,)):
    """
    重试装饰器
    
    Args:
        times: 重试次数
        delay: 每次重试间隔（秒）
        exceptions: 需要重试的异常类型
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for i in range(times):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if i == times - 1:
                        logger.error(f"Retry {times} times failed: {e}")
                        raise
                    logger.warning(f"Attempt {i+1} failed: {e}, retrying...")
                    time.sleep(delay)
            return None
        return wrapper
    return decorator