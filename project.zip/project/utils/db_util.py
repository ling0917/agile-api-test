import pymysql
from config.settings import CURRENT
from utils.log_util import get_logger

logger = get_logger("database")


class DBUtil:
    
    @staticmethod
    def get_connection():
        logger.info(f"DB: {CURRENT.DB_HOST}:{CURRENT.DB_PORT}/{CURRENT.DB_NAME}")
        try:
            return pymysql.connect(
                host=CURRENT.DB_HOST,
                port=CURRENT.DB_PORT,
                user=CURRENT.DB_USER,
                password=CURRENT.DB_PASSWORD,
                database=CURRENT.DB_NAME,
                charset="utf8mb4",
                cursorclass=pymysql.cursors.DictCursor
            )
        except pymysql.Error as e:
            logger.error(f"DB connect failed: {e}")
            raise
    
    @staticmethod
    def execute_query(sql, params=None):
        logger.info(f"Query: {sql}, params: {params}")
        conn = DBUtil.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql, params or ())
                result = cursor.fetchall()
                logger.info(f"Result: {len(result)} rows")
                return result
        except pymysql.Error as e:
            logger.error(f"Query failed: {e}")
            raise
        finally:
            conn.close()
            logger.debug("DB closed")
    
    @staticmethod
    def execute_update(sql, params=None):
        logger.info(f"Update: {sql}, params: {params}")
        conn = DBUtil.get_connection()
        try:
            with conn.cursor() as cursor:
                result = cursor.execute(sql, params or ())
                conn.commit()
                logger.info(f"Affected: {result}")
                return result
        except pymysql.Error as e:
            logger.error(f"Update failed: {e}")
            conn.rollback()
            raise
        finally:
            conn.close()
            logger.debug("DB closed")