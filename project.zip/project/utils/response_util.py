"""统一响应处理"""


class ResponseUtil:
    
    @staticmethod
    def is_success(resp):
        """判断请求是否成功"""
        return resp.status_code == 200
    
    @staticmethod
    def get_json(resp):
        """安全获取JSON"""
        try:
            return resp.json()
        except Exception:
            return None
    
    @staticmethod
    def extract_value(resp, *keys):
        """从JSON嵌套字典取值"""
        data = ResponseUtil.get_json(resp)
        if not data:
            return None
        
        for key in keys:
            if isinstance(data, dict) and key in data:
                data = data[key]
            else:
                return None
        return data