"""
AES对称加密工具
用于测试数据中的敏感信息加密存储
"""
import os
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


class CryptoUtil:
    """AES加密解密工具类"""
    
    # 固定盐值（实际项目可换更复杂的）
    SALT = b'agile_test_salt_2024'
    
    @classmethod
    def _get_key(cls, password: str = None) -> bytes:
        """从密码派生加密密钥"""
        # 优先从环境变量获取，其次用默认（仅本地开发）
        secret = password or os.getenv("AES_KEY", "agile-default-key-change-in-prod")
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=cls.SALT,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(secret.encode()))
        return key
    
    @classmethod
    def encrypt(cls, text: str, password: str = None) -> str:
        """加密明文"""
        if not text:
            return text
        f = Fernet(cls._get_key(password))
        return f.encrypt(text.encode()).decode()
    
    @classmethod
    def decrypt(cls, token: str, password: str = None) -> str:
        """解密密文"""
        if not token:
            return token
        # 检测是否是密文（Fernet密文特征）
        if not cls.is_encrypted(token):
            return token  # 明文直接返回
        
        f = Fernet(cls._get_key(password))
        return f.decrypt(token.encode()).decode()
    
    @classmethod
    def is_encrypted(cls, text: str) -> bool:
        """判断是否是密文格式"""
        if not text or len(text) < 20:
            return False
        try:
            # Fernet密文以gAAAA开头
            return text.startswith('gAAAA')
        except:
            return False


# 快捷函数
def encrypt(text: str, password: str = None) -> str:
    return CryptoUtil.encrypt(text, password)

def decrypt(token: str, password: str = None) -> str:
    return CryptoUtil.decrypt(token, password)

def is_encrypted(text: str) -> bool:
    """判断是否是密文（模块级快捷函数）"""
    return CryptoUtil.is_encrypted(text)