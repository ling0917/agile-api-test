# utils/request_util.py
import requests
from config.settings import CURRENT
from utils.log_util import get_logger

logger = get_logger("request")


class RequestUtil:
    
    @staticmethod
    def get(url, **kwargs):
        full_url = f"{CURRENT.BASE_URL}{url}"
        logger.info(f"GET: {full_url}")
        
        try:
            resp = requests.get(full_url, timeout=CURRENT.TIMEOUT, **kwargs)
            logger.info(f"Status: {resp.status_code}")
            logger.debug(f"Body: {resp.text[:500]}")
            return resp
        except requests.Timeout:
            logger.error(f"Timeout: {full_url}")
            raise
        except requests.RequestException as e:
            logger.error(f"Error: {e}")
            raise
    
    @staticmethod
    def post(url, **kwargs):
        full_url = f"{CURRENT.BASE_URL}{url}"
        logger.info(f"POST: {full_url}, params: {kwargs}")
        
        try:
            resp = requests.post(full_url, timeout=CURRENT.TIMEOUT, **kwargs)
            logger.info(f"Status: {resp.status_code}")
            logger.debug(f"Body: {resp.text[:500]}")
            return resp
        except requests.Timeout:
            logger.error(f"Timeout: {full_url}")
            raise
        except requests.RequestException as e:
            logger.error(f"Error: {e}")
            raise
    
    @staticmethod
    def put(url, **kwargs):
        """PUT 请求"""
        full_url = f"{CURRENT.BASE_URL}{url}"
        logger.info(f"PUT: {full_url}, params: {kwargs}")
        
        try:
            resp = requests.put(full_url, timeout=CURRENT.TIMEOUT, **kwargs)
            logger.info(f"Status: {resp.status_code}")
            logger.debug(f"Body: {resp.text[:500]}")
            return resp
        except requests.Timeout:
            logger.error(f"Timeout: {full_url}")
            raise
        except requests.RequestException as e:
            logger.error(f"Error: {e}")
            raise
    
    @staticmethod
    def delete(url, **kwargs):
        """DELETE 请求"""
        full_url = f"{CURRENT.BASE_URL}{url}"
        logger.info(f"DELETE: {full_url}")
        
        try:
            resp = requests.delete(full_url, timeout=CURRENT.TIMEOUT, **kwargs)
            logger.info(f"Status: {resp.status_code}")
            logger.debug(f"Body: {resp.text[:500]}")
            return resp
        except requests.Timeout:
            logger.error(f"Timeout: {full_url}")
            raise
        except requests.RequestException as e:
            logger.error(f"Error: {e}")
            raise